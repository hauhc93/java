package fire.smoke.zipposhop.subs;

public interface ZippoSubsConstant {
    String ITEM_TO_BUY_SKU_ID_1 = "buysubszippo1";
    String ITEM_TO_BUY_SKU_ID_2 = "buysubszippo2";
    String ITEM_TO_BUY_SKU_ID_3 = "buysubszippo3";
    String ITEM_TO_BUY_SKU_ID_4 = "buysubszippo4";
    String ITEM_TO_BUY_SKU_ID_5 = "buysubszippo5";
}