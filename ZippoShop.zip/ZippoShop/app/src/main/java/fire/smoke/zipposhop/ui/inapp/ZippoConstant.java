package fire.smoke.zipposhop.ui.inapp;

public interface ZippoConstant {
    String ITEM_TO_BUY_SKU_ID_1 = "buyzippo1";
    String ITEM_TO_BUY_SKU_ID_2 = "buyzippo2";
    String ITEM_TO_BUY_SKU_ID_3 = "buyzippo3";
    String ITEM_TO_BUY_SKU_ID_4 = "buyzippo4";
    String ITEM_TO_BUY_SKU_ID_5 = "buyzippo5";
}